# Copyright © 2026, Oracle and/or its affiliates.
# All rights reserved. Licensed under the Universal Permissive License (UPL), Version 1.0 as shown at https://oss.oracle.com/licenses/upl.

output "adb_db_id" {
  value = {
    for adw in oci_database_autonomous_database.adw :
    adw.display_name => adw.id
  }
}

output "ad" {
  value = {
    for idx, ad in oci_database_autonomous_database.adw :
    ad.db_name => { "connection_strings" : ad.connection_strings.0.all_connection_strings }
  }
}

output "db_connection" {
  value = try(one([for b in oci_database_autonomous_database.adw : b.connection_strings]), [])
}

output "private_endpoint_ip" {
  value = try(one([for b in oci_database_autonomous_database.adw : b.private_endpoint_ip]), null)
}

output "private_endpoint" {
  value = ([for b in oci_database_autonomous_database.adw : b.private_endpoint])
}

output "url" {
  value = try([for b in oci_database_autonomous_database.adw : b.connection_urls.0.sql_dev_web_url], [])
}

output "graph_studio_url" {
  value = try([for b in oci_database_autonomous_database.adw : b.connection_urls.0.graph_studio_url], [])
}

output "machine_learning_ui_url" {
  value = try([for b in oci_database_autonomous_database.adw : b.connection_urls.0.machine_learning_notebook_url], [])
}

output "adb_wallet_content" {
  value = try(oci_database_autonomous_database_wallet.autonomous_database_wallet["adw"].content, null)
}

output "database_fully_qualified_name" {
  value = try(trimprefix(split("/graphstudio", lower(join("\n", [for b in oci_database_autonomous_database.adw : b.connection_urls.0.graph_studio_url])))[0], "https://"), "")
}

output "adw" {
  value = {
    for adw in oci_database_autonomous_database.adw :
    adw.display_name => adw.id
  }
}

output "apex_url" {
  value = try([for b in oci_database_autonomous_database.adw : b.connection_urls.0.apex_url], [])
}

output "askoracle_select_ai_app_url" {
  value = try(join("", [split("/graphstudio", lower(join("\n", [for b in oci_database_autonomous_database.adw : b.connection_urls.0.graph_studio_url])))[0], "/ords/r/${one([for _, cfg in var.adw_params : cfg.u_name])}/chatdb"]), "")
}
