# Copyright © 2026, Oracle and/or its affiliates.
# All rights reserved. Licensed under the Universal Permissive License (UPL), Version 1.0 as shown at https://oss.oracle.com/licenses/upl.


terraform {
  required_version = ">= 0.15.0"
}

variable "tenancy_ocid" {
  type    = string
  default = ""
}

variable "region" {
  type    = string
  default = ""
}

variable "compartment_id" {
  type    = string
  default = ""
}

variable "adb_operation_mode" {
  type    = string
  default = "Provision a new Autonomous AI Database with the demo Schema and Applications"

  validation {
    condition = contains([
      "Provision a new Autonomous AI Database with the demo Schema and Applications",
      "Update an existing Autonomous AI Database by adding the demo Data and AI Application"
    ], var.adb_operation_mode)
    error_message = "Select either provisioning a new Autonomous AI Database or updating an existing Autonomous AI Database."
  }
}

variable "existing_autonomous_database_id" {
  type    = string
  default = ""
}

variable "existing_db_admin_password" {
  type      = string
  default   = ""
  sensitive = true
}

variable "existing_db_wallet_password" {
  type      = string
  default   = ""
  sensitive = true
}

variable "user_ocid" {
  type    = string
  default = ""
}

variable "fingerprint" {
  type    = string
  default = ""
}

variable "private_key_path" {
  type    = string
  default = ""
}

locals {
  effective_license_model = var.db_is_free_tier ? "LICENSE_INCLUDED" : var.db_license_model
  effective_compute_count = var.db_is_free_tier ? 2 : var.db_ecpus
}

# ADW Database Variables:

variable "db_name" {
  type    = string
  default = "MovieStreamWorkshop"
}

variable "db_password" {
  type    = string
  default = "WlsAtpDb1234#"
}

variable "db_compute_model" {
  type    = string
  default = "ECPU"
}

variable "db_ecpus" {
  type    = number
  default = 4
  # default = 2
}

variable "db_size_in_tbs" {
  type    = number
  default = 1
}

variable "db_workload" {
  type    = string
  default = "DW"
}

variable "db_version" {
  type    = string
  default = "26ai"
}

variable "db_enable_auto_scaling" {
  type    = bool
  default = false
}

variable "db_is_free_tier" {
  type    = bool
  default = false
}

variable "db_license_model" {
  type    = string
  default = "BRING_YOUR_OWN_LICENSE"
}

variable "db_data_safe_status" {
  type    = string
  default = "NOT_REGISTERED"
  # default = "REGISTERED"
}

variable "db_operations_insights_status" {
  type    = string
  default = "NOT_ENABLED"
  # default = "ENABLED"
}

variable "db_database_management_status" {
  type    = string
  default = "NOT_ENABLED"
  # default = "ENABLED"
}

# Workshop Settings

variable "llm_region" {
  type    = string
  default = "us-chicago-1"
}

variable "tag" {
  type = string
  # default = "gen-ai"
  default = "moviestream-analytics"
}

variable "u_name" {
  type    = string
  default = "MOVIESTREAM"
}

variable "u_pwd" {
  type    = string
  default = "watchS0meMovies#"
}

variable "run_post_load_procedures" {
  type    = bool
  default = true
}
